
# Problem Statement:

### Fetch and Display Data from an API
##### Description: Create a React component that fetches data from an API and displays it in a cards. Use the useEffect hook to perform the fetch operation using below api
https://fakestoreapi.com/products

### Example:

#### Fetch data from a sample API (e.g.).

##### Display the data in a list format.
##### Add filter options according to category of the products Category list can be fetch from
https://fakestoreapi.com/products/categories
api
