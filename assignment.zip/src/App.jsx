import { Card } from "./card";

function App() {
  return (
    <div>
      <h1>Product</h1>
      <Card />
    </div>
  );
}

export default App;
